﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.AnalysisServices;
using Microsoft.AnalysisServices.AdomdClient;
using System.Data;
using System.Data.SqlClient;

namespace ExecuteCommand
{
    public class ExecuteCommand
    {
        public void RunSQLQuery(String SQLSerer, String SQLDB, String TSQL)
        {
            string DBConn = "Data Source=" + SQLSerer + ";Initial Catalog=" + SQLDB + "; Integrated Security=SSPI;Connection Timeout=6000";
            SqlConnection conn = new SqlConnection(DBConn);
            SqlCommand cmd = new SqlCommand();
            conn.Open();
            cmd.Connection = conn;
            cmd.CommandTimeout = 6000;
            cmd.CommandText = TSQL;
            
             cmd.ExecuteReader();
        }
    }
}
