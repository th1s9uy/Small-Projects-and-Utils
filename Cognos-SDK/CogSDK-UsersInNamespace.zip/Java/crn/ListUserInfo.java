/**
 * ListUserInfo.java
 *
 * Copyright � 2004 Cognos Incorporated. All Rights Reserved.
 * Cognos and the Cognos logo are trademarks of Cognos Incorporated.
 *
 * Description: (KB 1007883) - CRN SDK Java Sample To Display the User Information of All the Users in a Namespace
 *
 *		This code sample demonstrates how to extract the user name,
 *              user ID and search path for each user in a given namespace.
 *
 * Note:  You must log in as a system administrator who is part of the same
 *        namespace as the users whose information are to be listed
 *
*/

import com.cognos.developer.schemas.bibus._2.*;

public class ListUserInfo {

  public CognosReportNetBindingStub oCrn = null;

  public void connectToReportServer (String endPoint) throws Exception
  {
  	//Create a connection to the ReportNet service
  	CognosReportNetServiceLocator service = new CognosReportNetServiceLocator();

    oCrn = new CognosReportNetBindingStub(new java.net.URL(endPoint), service);
    // Set the Axis request timeout
    oCrn.setTimeout(0);  // in milliseconds, 0 turns the timeout off
  }

  public String logon(String namespaceID, String uid, String pwd) throws Exception
  {
	  StringBuffer credentialXML = new StringBuffer();

	  credentialXML.append("<credential>");
	  credentialXML.append("<namespace>").append(namespaceID).append("</namespace>");
	  credentialXML.append("<username>").append(uid).append("</username>");
	  credentialXML.append("<password>").append(pwd).append("</password>");
	  credentialXML.append("</credential>");

	  String encodedCredentials = credentialXML.toString();

	  oCrn.logon(encodedCredentials, new String[]{}/* this parameter does nothing, but is required */);

	  return ("Logon successful as " + uid);
  }

	// Get account information for the users in the specified namespace.
	public void listUserInfo(String namespaceSearchPath) throws Exception
	{
		PropEnum props[] = new PropEnum[]{PropEnum.searchPath,
				PropEnum.defaultName,
				PropEnum.userName,
				PropEnum.name};
		BaseClass[] users = oCrn.query(namespaceSearchPath + "//account", props, new Sort[]{}, new QueryOptions());

		for(int i = 0; i < users.length; i++)
		{

			System.out.println("\n\ndefaultName is: " + users[i].getDefaultName().getValue());
			System.out.println("userName is: " + ((Account)users[i]).getUserName().getValue());
			System.out.println("searchPath is: " + users[i].getSearchPath().getValue());

			MultilingualToken multilingualName [] = users[i].getName().getValue();
			for(int j=0; j < multilingualName.length; j++)
			{
				System.out.println("name in the " + multilingualName[j].getLocale() + " locale is: " + multilingualName[j].getValue());
			}
		}
	}

  public static void main(String args[])
  {
  	String output = null;
    String endPoint = "http://localhost/crn/cgi-bin/cognos.cgi";
    // You must log in as a system administrator who is part of the same
    // namespace as the users whose information are to be listed
	String namespaceID = "namespaceID";
	String userID = "userID";
	String password = "password";
	String namespaceSearchPath = "CAMID(\"Series7\")";
	ListUserInfo security = new ListUserInfo();

	try
	{
		security.connectToReportServer(endPoint);
		output = security.logon(namespaceID, userID, password);
		System.out.println(output);
		security.listUserInfo(namespaceSearchPath);
	}
	catch (Exception ex)
	{
		ex.printStackTrace();
		System.out.println("\nAn error occurred\n");
	}
	System.out.println("\n\nDone");
  }
}
