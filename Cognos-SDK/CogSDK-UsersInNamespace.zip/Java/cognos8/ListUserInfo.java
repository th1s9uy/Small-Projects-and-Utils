/**
 * ListUserInfo.java
 *
 * Copyright � 2004 Cognos Incorporated. All Rights Reserved.
 * Cognos and the Cognos logo are trademarks of Cognos Incorporated.
 *
 * Description: (KB 1007883) - SDK Java Sample To Display the User Information of All the Users in a Namespace
 *
 *		This code sample demonstrates how to extract the user name,
 *              user ID and search path for each user in a given namespace.
 *
 * Note:  You must log in as a system administrator who is part of the same
 *        namespace as the users whose information are to be listed
 *
*/

import com.cognos.developer.schemas.bibus._3.*;

public class ListUserInfo {

 	public ContentManagerService_Port cmService = null;
	
  public void connectToReportServer (String endPoint) throws Exception
  {
  	//Create a connection to the CM service
  	
    ContentManagerService_ServiceLocator cmServiceLocator = new ContentManagerService_ServiceLocator();
    try
	{
		cmService = cmServiceLocator.getcontentManagerService(new java.net.URL(endPoint));
		
	}
	catch (Exception e)
	{
		System.out.println(e);
	}
  }

  public String logon(String namespaceID, String uid, String pwd) throws Exception
  {
	  StringBuffer credentialXML = new StringBuffer();

	  credentialXML.append("<credential>");
	  credentialXML.append("<namespace>").append(namespaceID).append("</namespace>");
	  credentialXML.append("<username>").append(uid).append("</username>");
	  credentialXML.append("<password>").append(pwd).append("</password>");
	  credentialXML.append("</credential>");

	  String encodedCredentials = credentialXML.toString();

	  try
		{
			cmService.logon(new XmlEncodedXML(encodedCredentials), null);
		}
		catch (Exception ex)
		{
			return("exception thrown " + ex);
		}
	  return ("Logon successful as " + uid);
  }

	// Get account information for the users in the specified namespace.
	public void listUserInfo(String namespaceSearchPath) throws Exception
	{
		PropEnum props[] = new PropEnum[]{PropEnum.searchPath,
				PropEnum.defaultName,
				PropEnum.userName,
				PropEnum.name};
		BaseClass[] users = cmService.query(new SearchPathMultipleObject(namespaceSearchPath+"//account"), props, new Sort[]{}, new QueryOptions());

		for(int i = 0; i < users.length; i++)
		{

			System.out.println("\n\ndefaultName is: " + users[i].getDefaultName().getValue());
			System.out.println("userName is: " + ((Account)users[i]).getUserName().getValue());
			System.out.println("searchPath is: " + users[i].getSearchPath().getValue());

			MultilingualToken multilingualName [] = users[i].getName().getValue();
			for(int j=0; j < multilingualName.length; j++)
			{
				System.out.println("name in the " + multilingualName[j].getLocale() + " locale is: " + multilingualName[j].getValue());
			}
		}
	}

  public static void main(String args[])
  {
  	String output = null;
    String endPoint = "http://localhost:9300/p2pd/servlet/dispatch";
    // You must log in as a system administrator who is part of the same
    // namespace as the users whose information are to be listed
	String namespaceID = "Default";
	String userID = "Administrator";
	String password = "sa";
	String namespaceSearchPath = "CAMID(\"Default\")";
	ListUserInfo security = new ListUserInfo();

	try
	{
		security.connectToReportServer(endPoint);
		output = security.logon(namespaceID, userID, password);
		System.out.println(output);
		security.listUserInfo(namespaceSearchPath);
	}
	catch (Exception ex)
	{
		ex.printStackTrace();
		System.out.println("\nAn error occurred\n");
	}
	System.out.println("\n\nDone");
  }
}
