/**
 * AddPortalTabSetHomePage.java
 *
 * Copyright � 2007 Cognos Incorporated. All Rights Reserved.
 * Cognos and the Cognos logo are trademarks of Cognos Incorporated.
 *
 * Description: (KB 1021198) - SDK sample to copy portal tabs from one account to another in Cognos 8
 * 
 *				This sample demonstrates how to copy portal tabs from
 *				one account to another.  It will also set the home page 
 *				of the template account to be the home page of the target 
 *				account after it is copied over. If the home 
 *				page of the template account is not one the transfered pages, 
 *				the first portal tab found in the template account is used as 
 *				the home page of the target account.
 */

using System;
using System.Collections;
using cognosdotnet;



public class AddPortalTabSetHomePage
	{
		// Edit the values of these variables before running the application.
		// It is required to login as the system Administrator, to be able to manage the portal pages.
		// connection URL to the Cognos 8 service
		private String endPoint = "http://localhost:9300/p2pd/servlet/dispatch";
		// log in as a Cognos system administrator, modify these as required.
		private String namespaceID = "namespaceID";
		private String userID = "userID";
		private String password = "password";
		// search path of the account from which the portal tabs will be copied
		private String templateSearchPath = "CAMID(\"LDAP:u:uid=user1,ou=people\")";
		// search path of the account to which the portal tabs will be added
		private String targetSearchPath = "CAMID(\"LDAP:u:uid=user2,ou=people\")";
		// if you wish to add the portal tabs to all the users in a namespace,
		// use a similar search path syntax to the following:
		// String targetSearchPath = "CAMID(\"LDAP\")//account";
		
		contentManagerService1 cmService = null;

		public static void Main()
		{
			AddPortalTabSetHomePage test = new AddPortalTabSetHomePage();

			try
			{
				test.connectToCognos8Server(test.endPoint);
				test.logon(test.namespaceID, test.userID, test.password);
				test.addPortalTabsAndSetHomePage(test.templateSearchPath, test.targetSearchPath);

				Console.Write("\nDone.");
			}
			catch (Exception e)
			{
				Console.Write("\n" + e.GetBaseException());
			}
		}


		/**
		* Connect to the Cognos 8 server.
		*
		* @param 	endPoint	The URL for the Cognos 8 server
		*
		*/
		public void connectToCognos8Server(String endPoint)
		{
			// create a connection to the Cognos 8 service
			
			cmService = new contentManagerService1();
			cmService.Url = endPoint;
			
		}
		
		/**
		* Logon to Cognos 8.
		*
		* @param 	namespaceID		Namespace ID
		* @param	uid				User ID
		* @param	pwd				Password
		* 
		*/
		public void logon(string namespaceID, string userID, string password)
		{
			try
			{
				String credentialXML = "<credential>" +
					"<namespace>" + namespaceID + "</namespace>" +
					"<username>" + userID + "</username>" +
					"<password>" + password + "</password>" +
					"</credential>";
	        
				xmlEncodedXML xmlExcodedCredentials = new xmlEncodedXML();
				xmlExcodedCredentials.Value = credentialXML;

				cmService.logon(xmlExcodedCredentials, new searchPathSingleObject[]{});

				Console.Write("\nLogon successful as " + userID);
			}
			catch (Exception e)
			{
				Console.Write("\n" + e.GetBaseException());
			}
		}

		/**
		* Create a list of the portal tabs found in the template account.
		*
		* @param 	templateInfo	Template account
		* @return					A vector containing all the portal tabs in the template account.
		*
		*/
		public ArrayList getTemplatePortalTabs(baseClass[] templateInfo)
		{
    		ArrayList templatePortalTabs = new ArrayList();
			baseClass[] templatePortalPages = ((account)templateInfo[0]).portalPages.value;

			try
			{
				for(int i = 0; i < templatePortalPages.Length; i++)
				{
					// filter out the template account's Public Folders and My Folders
					if(templatePortalPages[i].searchPath.value.IndexOf("/pagelet[@name='") > 0)
					{
						templatePortalTabs.Add(templatePortalPages[i]);	
					}
				}
			
				return templatePortalTabs;
			}
			catch(Exception e)
			{
				Console.Write("\n" + e.GetBaseException());
				return new ArrayList();
			}
		}
	    
		/**
		* Create a list of the current portal tabs found in the target account(s).
		*
		* @param 	templateInfo	Template account
		* @param 	targetInfo		Target account(s)
		* @return					A vector containing all the current portal tabs in the target account(s).
		*
		*/
		public ArrayList getAllCurrentTargetPortalTabs(baseClass[] templateInfo, baseClass[] targetInfo)
		{
    		ArrayList allTargetAccountsPortalTabs = new ArrayList();
			
			for(int i = 0; i < targetInfo.Length; i++)
			{
				// exclude the template account from the target list
				if (targetInfo[i].searchPath.value.CompareTo(templateInfo[0].searchPath.value) != 0)
				{
					ArrayList singleTargetAccountPortalTabs = new ArrayList();
					// include the account search path to keep track of which portal tabs are in which account
					singleTargetAccountPortalTabs.Add(targetInfo[i].searchPath.value);
					
					baseClass[] targetPortalPages = ((account)targetInfo[i]).portalPages.value;

					if(targetPortalPages != null && targetPortalPages.Length > 0)
					{
						for(int j = 0; j < targetPortalPages.Length; j++)
						{
							singleTargetAccountPortalTabs.Add(targetPortalPages[j]);
						}
					}
					allTargetAccountsPortalTabs.Add(singleTargetAccountPortalTabs);
				}
			}
			
			return allTargetAccountsPortalTabs;
		}

	public String getTemplateHomePage(baseClass[] templateInfo)
	{			// check whether the template homePage portal option is set
		option[] templatePortalOptions = ((account)templateInfo[0]).options.value;
		for (int l = 0; l < templatePortalOptions.Length; l++)
		{
			if (templatePortalOptions[l] is portalOptionString)
			{
				portalOptionString templateOption = (portalOptionString)templatePortalOptions[l];
				if (templateOption.name == portalOptionEnum.homePage)
				{
					// filter out the template account's Public Folders and My Folders
					if (templateOption.value.IndexOf("%2fpagelet%5b%40name%3d%27") > 0)
					{
						return templateOption.value;
					}
				}
			}
		}
		return null;
	} 
	    
		/**
		* Add the portal tabs from the template account to the list of the current portal tabs found in the target account(s).
		*
		* @param 	templatePortalTabs	List of the template account's portal tabs
		* @param 	targetPortalTabs	List of the target account(s) current portal tabs
		* @return						A vector with the two lists merged.
		*
		*/
		public ArrayList addTemplatePortalTabsToCurrentTargetPortalTabs(ArrayList templatePortalTabs, ArrayList targetPortalTabs)
		{
			
    		for(int i = 0; i < targetPortalTabs.Count; i++)
    		{
    			ArrayList singleTargetAccountPortalTabs = new ArrayList();
    			singleTargetAccountPortalTabs = (ArrayList)targetPortalTabs[i];
	    		
				for(int j = 0; j < templatePortalTabs.Count; j++)
				{
					// check whether this target account already has this portal tab
					Boolean foundSamePortalTab = false;
					for(int k = 0; !foundSamePortalTab && k < (singleTargetAccountPortalTabs.Count - 1); k++)
					{
						if(((baseClass)singleTargetAccountPortalTabs[k + 1]).searchPath.value.CompareTo(((baseClass)templatePortalTabs[j]).searchPath.value) == 0)
						{
							foundSamePortalTab = true;
						}
					}
					// only add the portal tab if the target account does not already have it 
					if(!foundSamePortalTab)
					{
						singleTargetAccountPortalTabs.Add(templatePortalTabs[j]);
					}
				}
    		}
			
			return targetPortalTabs;
		}

        /**
        * Add the portal tabs in the template account to the target account(s) and
        * set the home page of the template account to be the home page of the
        * target account after it is copied over. If the home page of the template
        * account is not one the transfered pages, the first portal tab found in
        * the template account is used as the home page of the target account.
        *
        * @param 	templateSearchPath	Search path of the template account
        * @param	targetSearchPath	Search path of the target account
        *
        */
        public void addPortalTabsAndSetHomePage(String templateSearchPath, String targetSearchPath)
		{
			searchPathMultipleObject templateSPMulti = new searchPathMultipleObject();
			searchPathMultipleObject targetSPMulti = new searchPathMultipleObject();

			templateSPMulti.Value = templateSearchPath;
			targetSPMulti.Value = targetSearchPath;

			propEnum[] props = new propEnum[] {propEnum.options, propEnum.portalPages, propEnum.searchPath};
			
			baseClass[] templateInfo = cmService.query(templateSPMulti, props, new sort[]{}, new queryOptions());
			baseClass[] targetInfo = cmService.query(targetSPMulti, props, new sort[]{}, new queryOptions());

            if (templateInfo.Length > 0) {
			    if (targetInfo.Length > 0) {
			        String templateHomePage = getTemplateHomePage(templateInfo);

    		        ArrayList templatePortalTabs = getTemplatePortalTabs(templateInfo);
    		        ArrayList targetPortalTabs = getAllCurrentTargetPortalTabs(templateInfo, targetInfo);
	    	
    		        targetPortalTabs = addTemplatePortalTabsToCurrentTargetPortalTabs(templatePortalTabs, targetPortalTabs);
	    	
    		        int k = 0;
    		        Boolean foundMatchingAccount = false;
    		        for(int i = 0; i < targetPortalTabs.Count; i++)
    		        {
    			        ArrayList singleTargetAccountPortalTabs = new ArrayList();
    			        singleTargetAccountPortalTabs = (ArrayList)targetPortalTabs[i];
	    		
    			// match up the accounts in both lists
    			        while(!foundMatchingAccount && k < targetInfo.Length)
    			        {
    				        if(targetInfo[k].searchPath.value.CompareTo(singleTargetAccountPortalTabs[0].ToString()) == 0)
    				        {
    					        foundMatchingAccount = true;
    				        }
    				        else
    				        {
    					        k++;
    				        }
    			        }
    			        if(foundMatchingAccount)
    			        {
    				// do not count the account search path stored at the beginning of the vector when calculating the size
    				        baseClass[] updatedPortalTabs = new baseClass[(singleTargetAccountPortalTabs.Count - 1)];
	    			
    				        for(int j = 0; j < (singleTargetAccountPortalTabs.Count - 1); j++)
    				        {
    					        updatedPortalTabs[j] = (baseClass)singleTargetAccountPortalTabs[j + 1];
    				        }

					        baseClassArrayProp allPortalTabs = new baseClassArrayProp();
					        allPortalTabs.value = updatedPortalTabs;
					        ((account)targetInfo[k]).portalPages = allPortalTabs;
    				
					// Checking whether the homePage portal option is already set on the Target Account.
                    // This code sets the home page of the template account to be the home page of the
	                // target account after it is copied over. If the home page of the template
	                // account is not one the transfered pages, the first portal tab found in
                    // the template account is used as the home page of the target account.
					// It can be modified or hard coded to set the homepage to another portal tab.

					        option[] portalOpts = ((account)targetInfo[k]).options.value;
				
    				        Boolean foundExistingHomePageOption = false;
                            Boolean noProfile = false;
						    if (portalOpts == null)
							    noProfile = true;
                            if (!noProfile)
                            {
                                for (int l = 0; l < portalOpts.Length; l++)
                                {
                                    if (portalOpts[l] is portalOptionString)
                                    {
                                        portalOptionString option = (portalOptionString)portalOpts[l];
                                        if (option.name == portalOptionEnum.homePage)
                                        {
                                            if (templateHomePage != null)
                                            {
                                                option.value = templateHomePage;
                                            }
                                            else  // set the home page to the first template portal page
                                            {
                                                option.value = "b_action=xts.run&m=portal/cc.xts&m_tabPath=" + ((baseClass)templatePortalTabs[0]).searchPath.value;
                                            }
                                            foundExistingHomePageOption = true;
                                        }
                                    }
                                }
                            }
    				        if(!foundExistingHomePageOption)
    				        {
    					        portalOptionString homePage = new portalOptionString();
    					        homePage.name = portalOptionEnum.homePage;
						        if (templateHomePage != null)
						        {
							        homePage.value = templateHomePage;
						        }
						        else  // set the home page to the first template portal page
						        {
							        homePage.value = "b_action=xts.run&m=portal/cc.xts&m_tabPath=" + ((baseClass)templatePortalTabs[0]).searchPath.value;
						        }
                                option[] updatedPortalOptions = null;
                                if (noProfile)
                                {
									portalOptionInt automaticPageRefresh = new portalOptionInt();
									automaticPageRefresh.name = portalOptionEnum.automaticPageRefresh;
									automaticPageRefresh.value = 30;
									portalOptionInt linesPerPage = new portalOptionInt();
									linesPerPage.name = portalOptionEnum.linesPerPage;
									linesPerPage.value = 15;
									updatedPortalOptions = new option[3];
									updatedPortalOptions[0] = automaticPageRefresh;
									updatedPortalOptions[1] = linesPerPage;
									updatedPortalOptions[2] = homePage;
                                }
                                else
                                {
                                    updatedPortalOptions = new option[portalOpts.Length + 1];
                                    System.Array.Copy(portalOpts, 0, updatedPortalOptions, 0, portalOpts.Length);
                                    updatedPortalOptions[portalOpts.Length] = homePage;
                                }
        				        optionArrayProp allPortalOptions = new optionArrayProp();
        				        allPortalOptions.value = updatedPortalOptions;
    					        ((account)targetInfo[k]).options = allPortalOptions;
					        }    			
	    			
    				// update each account, one at a time
    				        cmService.update(new baseClass[]{targetInfo[k]}, new updateOptions());
			
    				        Console.Write("\nAdded the portal tabs from the template account to user " + targetInfo[k].searchPath.value);
    			        }
    			        foundMatchingAccount = false;
    		        } 
   	             } else {
                            Console.Write("\nNo target account was found using the following search path:\n");
				            Console.Write(targetSearchPath);
                            Console.Write("\nPlease verify the search path using Cognos Connection or cm_tester.htm");
			    }
		    } else {
                        Console.Write("\nNo template account was found using the following search path:\n");
			            Console.Write(templateSearchPath);
                        Console.Write("\nPlease verify the search path using Cognos Connection or cm_tester.htm");
		    }
		}
	}
