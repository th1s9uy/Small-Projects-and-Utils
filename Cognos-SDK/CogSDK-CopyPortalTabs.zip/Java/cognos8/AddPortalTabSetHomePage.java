package cognos8;

/**
 * AddPortalTabSetHomePage.java
 *
 * Copyright � 2005 Cognos Incorporated. All Rights Reserved.
 * Cognos and the Cognos logo are trademarks of Cognos Incorporated.
 *
 * Description: (KB 1021198) - SDK sample to copy portal tabs from one account to another in Cognos 8 - cognos8_3
 * 
 *				This sample demonstrates how to copy portal tabs from
 *				one account to another.  
 *				It will also set the home page of the template account to be the home page of the target 
 *				account after it is copied over. 
 *				If the home page of the template account is not one of the transfered pages, 
 *				the first portal tab found in the template account is used as the home page of the target account.
 */
import java.util.Vector;

import com.cognos.developer.schemas.bibus._3.Account;
import com.cognos.developer.schemas.bibus._3.BaseClass;
import com.cognos.developer.schemas.bibus._3.BaseClassArrayProp;
import com.cognos.developer.schemas.bibus._3.ContentManagerServiceStub;
import com.cognos.developer.schemas.bibus._3.ContentManagerService_ServiceLocator;
import com.cognos.developer.schemas.bibus._3.Option;
import com.cognos.developer.schemas.bibus._3.OptionArrayProp;
import com.cognos.developer.schemas.bibus._3.PortalOptionEnum;
import com.cognos.developer.schemas.bibus._3.PortalOptionInt;
import com.cognos.developer.schemas.bibus._3.PortalOptionString;
import com.cognos.developer.schemas.bibus._3.PropEnum;
import com.cognos.developer.schemas.bibus._3.QueryOptions;
import com.cognos.developer.schemas.bibus._3.SearchPathMultipleObject;
import com.cognos.developer.schemas.bibus._3.SearchPathSingleObject;
import com.cognos.developer.schemas.bibus._3.Sort;
import com.cognos.developer.schemas.bibus._3.UpdateOptions;
import com.cognos.developer.schemas.bibus._3.XmlEncodedXML;

public class AddPortalTabSetHomePage {
	public ContentManagerServiceStub cmService = null;

	/**
	 * Connect to the Cognos 8 server.
	 * 
	 * @param endPoint
	 *            The URL for the Cognos 8 server
	 * 
	 */
	public void connectToCognos8Server(String endPoint) throws Exception {
		// create a connection to the Cognos 8 service
		ContentManagerService_ServiceLocator cmServiceLocator = new ContentManagerService_ServiceLocator();
		cmService = new ContentManagerServiceStub(new java.net.URL(endPoint),
				cmServiceLocator);

		// set the Axis request timeout
		cmService.setTimeout(0); // in milliseconds, 0 turns the timeout off
	}

	/**
	 * Logon to Cognos 8.
	 * 
	 * @param namespaceID
	 *            Namespace ID
	 * @param uid
	 *            User ID
	 * @param pwd
	 *            Password
	 * 
	 */
	public void logon(String namespaceID, String uid, String pwd)
			throws Exception {
		StringBuffer credentialXML = new StringBuffer();

		credentialXML.append("<credential>");
		credentialXML.append("<namespace>").append(namespaceID).append("</namespace>");
		credentialXML.append("<username>").append(uid).append("</username>");
		credentialXML.append("<password>").append(pwd).append("</password>");
		credentialXML.append("</credential>");

		String encodedCredentials = credentialXML.toString();

		cmService.logon(new XmlEncodedXML(encodedCredentials),
				new SearchPathSingleObject[] {});

		System.out.println("Logon successful as " + uid);
	}

	/**
	 * Create a list of the portal tabs found in the template account.
	 * 
	 * @param templateInfo
	 *            Template account
	 * @return A vector containing all the portal tabs in the template account.
	 * 
	 */
	public Vector getTemplatePortalTabs(BaseClass[] templateInfo)
			throws Exception {
		Vector templatePortalTabs = new Vector();

		BaseClass[] templatePortalPages = ((Account) templateInfo[0])
				.getPortalPages().getValue();

		for (int i = 0; i < templatePortalPages.length; i++) {
			// filter out the template account's Public Folders and My Folders
			if (templatePortalPages[i].getSearchPath().getValue().indexOf(
					"/pagelet[@name='") > 0) {
				templatePortalTabs.add(templatePortalPages[i]);
			}
		}

		return templatePortalTabs;
	}

	public String getTemplateHomePage(BaseClass[] templateInfo) { // check
		// whether
		// the
		// template
		// homePage
		// portal
		// option is
		// set
		Option[] templatePortalOptions = ((Account) templateInfo[0])
				.getOptions().getValue();
		for (int l = 0; l < templatePortalOptions.length; l++) {
			if (templatePortalOptions[l] instanceof PortalOptionString) {
				PortalOptionString templateOption = (PortalOptionString) templatePortalOptions[l];
				if (templateOption.getName() == PortalOptionEnum.homePage) {
					// filter out the template account's Public Folders and My
					// Folders
					if (templateOption.getValue().indexOf(
							"%2fpagelet%5b%40name%3d%27") > 0) {
						return templateOption.getValue();
					}
				}
			}
		}
		return null;
	}

	/**
	 * Create a list of the current portal tabs found in the target account(s).
	 * 
	 * @param templateInfo
	 *            Template account
	 * @param targetInfo
	 *            Target account(s)
	 * @return A vector containing all the current portal tabs in the target
	 *         account(s).
	 * 
	 */
	public Vector getAllCurrentTargetPortalTabs(BaseClass[] templateInfo,
			BaseClass[] targetInfo) throws Exception {
		Vector allTargetAccountsPortalTabs = new Vector();

		for (int i = 0; i < targetInfo.length; i++) {
			// exclude the template account from the target list
			if (targetInfo[i].getSearchPath().getValue().compareTo(
					templateInfo[0].getSearchPath().getValue()) != 0) {
				Vector singleTargetAccountPortalTabs = new Vector();
				// include the account search path to keep track of which portal
				// tabs are in which account
				singleTargetAccountPortalTabs.add(targetInfo[i].getSearchPath()
						.getValue());

				BaseClass[] targetPortalPages = ((Account) targetInfo[i])
						.getPortalPages().getValue();

				if (targetPortalPages != null && targetPortalPages.length > 0) {
					for (int j = 0; j < targetPortalPages.length; j++) {
						singleTargetAccountPortalTabs.add(targetPortalPages[j]);
					}
				}
				allTargetAccountsPortalTabs.add(singleTargetAccountPortalTabs);
			}
		}

		return allTargetAccountsPortalTabs;
	}

	/**
	 * Add the portal tabs from the template account to the list of the current
	 * portal tabs found in the target account(s).
	 * 
	 * @param templatePortalTabs
	 *            List of the template account's portal tabs
	 * @param targetPortalTabs
	 *            List of the target account(s) current portal tabs
	 * @return A vector with the two lists merged.
	 * 
	 */
	public Vector addTemplatePortalTabsToCurrentTargetPortalTabs(
			Vector templatePortalTabs, Vector targetPortalTabs)
			throws Exception {

		for (int i = 0; i < targetPortalTabs.size(); i++) {
			Vector singleTargetAccountPortalTabs = new Vector();
			singleTargetAccountPortalTabs = (Vector) targetPortalTabs.get(i);

			for (int j = 0; j < templatePortalTabs.size(); j++) {
				// check whether this target account already has this portal tab
				boolean foundSamePortalTab = false;
				for (int k = 0; !foundSamePortalTab
						&& k < singleTargetAccountPortalTabs.size() - 1; k++) {
					if (((BaseClass) singleTargetAccountPortalTabs.get(k + 1))
							.getSearchPath().getValue().compareTo(
									((BaseClass) templatePortalTabs.get(j))
											.getSearchPath().getValue()) == 0) {
						foundSamePortalTab = true;
					}
				}
				// only add the portal tab if the target account does not
				// already have it
				if (!foundSamePortalTab) {
					singleTargetAccountPortalTabs
							.add(templatePortalTabs.get(j));
				}
			}
		}

		return targetPortalTabs;
	}

	/**
	 * Add the portal tabs in the template account to the target account(s) and
	 * set the home page of the template account to be the home page of the
	 * target account after it is copied over. If the home page of the template
	 * account is not one the transfered pages, the first portal tab found in
	 * the template account is used as the home page of the target account.
	 * 
	 * @param templateSearchPath
	 *            Search path of the template account
	 * @param targetSearchPath
	 *            Search path of the target account
	 * 
	 */
	public void addPortalTabsAndSetHomePage(String templateSearchPath,
			String targetSearchPath) throws Exception {
		PropEnum[] props = new PropEnum[] { PropEnum.options,
				PropEnum.portalPages, PropEnum.searchPath };

		BaseClass[] templateInfo = cmService.query(
				new SearchPathMultipleObject(templateSearchPath), props,
				new Sort[] {}, new QueryOptions());
		BaseClass[] targetInfo = cmService.query(new SearchPathMultipleObject(
				targetSearchPath), props, new Sort[] {}, new QueryOptions());
		if (templateInfo.length > 0) {
			if (targetInfo.length > 0) {
				String templateHomePage = getTemplateHomePage(templateInfo);

				Vector templatePortalTabs = getTemplatePortalTabs(templateInfo);
				Vector targetPortalTabs = getAllCurrentTargetPortalTabs(
						templateInfo, targetInfo);

				targetPortalTabs = addTemplatePortalTabsToCurrentTargetPortalTabs(
						templatePortalTabs, targetPortalTabs);

				int k = 0;
				boolean foundMatchingAccount = false;
				for (int i = 0; i < targetPortalTabs.size(); i++) {
					Vector singleTargetAccountPortalTabs = new Vector();
					singleTargetAccountPortalTabs = (Vector) targetPortalTabs
							.get(i);

					// match up the accounts in both lists
					while (!foundMatchingAccount && k < targetInfo.length) {
						if (targetInfo[k].getSearchPath().getValue()
								.compareTo(
										singleTargetAccountPortalTabs.get(0)
												.toString()) == 0) {
							foundMatchingAccount = true;
						} else {
							k++;
						}
					}
					if (foundMatchingAccount) {
						// do not count the account search path stored at the
						// beginning of the vector when calculating the size
						BaseClass[] updatedPortalTabs = new BaseClass[singleTargetAccountPortalTabs
								.size() - 1];

						for (int j = 0; j < singleTargetAccountPortalTabs
								.size() - 1; j++) {
							updatedPortalTabs[j] = (BaseClass) singleTargetAccountPortalTabs
									.get(j + 1);
						}
						BaseClassArrayProp allPortalTabs = new BaseClassArrayProp();
						allPortalTabs.setValue(updatedPortalTabs);
						((Account) targetInfo[k]).setPortalPages(allPortalTabs);

						Option[] portalOptions = ((Account) targetInfo[k])
								.getOptions().getValue();

						// check whether the homePage portal option is already
						// set
						boolean foundExistingHomePageOption = false;
						boolean noProfile = false;
						if (portalOptions == null)
							noProfile = true;
						if (!noProfile) {
							for (int l = 0; l < portalOptions.length; l++) {
								if (portalOptions[l] instanceof PortalOptionString) {
									PortalOptionString option = (PortalOptionString) portalOptions[l];
									if (option.getName() == PortalOptionEnum.homePage) {
										if (templateHomePage != null) {
											option.setValue(templateHomePage);
											
										} else // set the home page to the first template portal page
										{
											option
													.setValue("b_action=xts.run&m=portal/cc.xts&m_tabPath="
															+ ((BaseClass) templatePortalTabs
																	.get(0))
																	.getSearchPath()
																	.getValue());
										}
										foundExistingHomePageOption = true;
										System.out.println("Set home page to the first Template portal page copied.");
									}
								}
							}
						}
						if (!foundExistingHomePageOption) {
							PortalOptionString homePage = new PortalOptionString();
							homePage.setName(PortalOptionEnum.homePage);
							if (templateHomePage != null) {
								homePage.setValue(templateHomePage);
							} else // set the home page to the first template
							// portal page
							{
								homePage
										.setValue("b_action=xts.run&m=portal/cc.xts&m_tabPath="
												+ ((BaseClass) templatePortalTabs
														.get(0))
														.getSearchPath()
														.getValue());
								
							}

							Option[] updatedPortalOptions = null;
							if (noProfile) {
								PortalOptionInt automaticPageRefresh = new PortalOptionInt();
								automaticPageRefresh
										.setName(PortalOptionEnum.automaticPageRefresh);
								automaticPageRefresh.setValue(30);
								PortalOptionInt linesPerPage = new PortalOptionInt();
								linesPerPage
										.setName(PortalOptionEnum.linesPerPage);
								linesPerPage.setValue(15);
								updatedPortalOptions = new Option[3];
								updatedPortalOptions[0] = automaticPageRefresh;
								updatedPortalOptions[1] = linesPerPage;
								updatedPortalOptions[2] = homePage;
							} else {
								updatedPortalOptions = new Option[portalOptions.length + 1];

								System.arraycopy(portalOptions, 0,
										updatedPortalOptions, 0,
										portalOptions.length);

								updatedPortalOptions[portalOptions.length] = homePage;
							}
							OptionArrayProp allPortalOptions = new OptionArrayProp();
							allPortalOptions.setValue(updatedPortalOptions);
							((Account) targetInfo[k])
									.setOptions(allPortalOptions);
						}

						// update each account, one at a time
						cmService.update(new BaseClass[] { targetInfo[k] },
								new UpdateOptions());

						System.out
								.println("Added the portal tabs from the template account to user "
										+ targetInfo[k].getSearchPath()
												.getValue());
					}
					foundMatchingAccount = false;
				}
			} else {
				System.out
						.println("No target account was found using the following search path:");
				System.out.println(targetSearchPath);
				System.out
						.println("Please verify the search path using Cognos Connection or cm_tester.htm");
			}
		} else {
			System.out
					.println("No template account was found using the following search path:");
			System.out.println(templateSearchPath);
			System.out
					.println("Please verify the search path using Cognos Connection or cm_tester.htm");
		}
	}

	public static void main(String[] args) {
		// Edit the values of these variables before running the application.
		// It is required to login as the system Administrator, to be able to
		// manage the portal pages.
		// connection URL to the Cognos 8 service
		String endPoint = "http://localhost:9300/p2pd/servlet/dispatch";
		// log in as a Cognos system administrator, modify these as required.
		String namespaceID = "namespaceID";
		String userID = "userID";
		String password = "password";
		
		// search path of the account from which the portal tabs will be copied
		String templateSearchPath = "CAMID(\"LDAP:u:uid=user1,ou=people\")";

		// search path of the account to which the portal tabs will be added
		String targetSearchPath = "CAMID(\"LDAP:u:uid=user2,ou=people\")";

		// if you wish to add the portal tabs to all the users in a namespace,
		// use a similar search path syntax to the following:
		//String targetSearchPath = "CAMID(\"LDAP\")//account";

		AddPortalTabSetHomePage test = new AddPortalTabSetHomePage();

		try {
			test.connectToCognos8Server(endPoint);

			test.logon(namespaceID, userID, password);

			test.addPortalTabsAndSetHomePage(templateSearchPath,
					targetSearchPath);

			System.out.println("\nDone.");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}