using System;
using cognosdotnet_2_0;

/**
 * QueryContentStore.cs
 *
 * Copyright � Cognos Incorporated. All Rights Reserved.
 * Cognos and the Cognos logo are trademarks of Cognos Incorporated.
 *
 * Description: (KB 1027119) - SDK: How to Retrieve all reports for a package 
 * 
 */

namespace QueryContentStore
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class QueryContentStore
	{

		private contentManagerService1 cmService = null;		 
	 
		private string endPoint 	= "http://localhost:9300/p2pd/servlet/dispatch";	
	
		private string namespaceID	= "namespaceID";
		private string userID		= "userID";
		private string password		= "password";

        private string searchPackageName = "/content/package[@name='GO Data Warehouse']";
		
		public QueryContentStore()
		{
			try
			{
				cmService = new contentManagerService1();
				cmService.Url = endPoint; 
				quickLogon(namespaceID, userID, password );
			}
			catch(Exception e)
			{
				Console.WriteLine(e.Message);
			}
		
		}
		/// <summary>
		/// Log on to C8 using the given credential information.
		/// </summary>
		/// <param name="userNamespace">The name of the C8 security namespace.</param>
		/// <param name="userID">The user's login name.</param>
		/// <param name="userPass">The user's password.</param>
		public void quickLogon( string userNamespace, string userID, string password )
		{
			try
			{	
				System.Text.StringBuilder credentialXML = new System.Text.StringBuilder("<credential>" );
				credentialXML.AppendFormat( "<namespace>{0}</namespace>", userNamespace );
				credentialXML.AppendFormat( "<username>{0}</username>", userID );
				credentialXML.AppendFormat( "<password>{0}</password>", password );
				credentialXML.Append( "</credential>" );

				//TODO - encode this, don't just toString it.
				string encodedCredentials = credentialXML.ToString ();
				xmlEncodedXML xmlEncodedCredentials = new xmlEncodedXML();
				xmlEncodedCredentials.Value = encodedCredentials;
				
				cmService.logon(xmlEncodedCredentials, null);
						
			}
			catch(Exception e)
			{
				Console.WriteLine (e.ToString());
			}
		}

		private void retrieveAllReports(string searchP)
		{
			try
			{
				searchPathMultipleObject searchPobj = new searchPathMultipleObject();				
				searchPobj.Value = searchP;
				
				propEnum []props = {propEnum.type, propEnum.defaultName, propEnum.searchPath, 
									propEnum.metadataModelPackage, propEnum.objectClass};
								
				baseClass []bc = cmService.query(searchPobj,props, new sort[]{}, new queryOptions());

				Console.WriteLine ("Objects Referencing package: " + searchPackageName);
		           
				for (int i=0; i< bc.Length ; i++)
				{ 
					//Print the name just top confirm that it is not useful in this case 
					//and it is almost the same for each output
					string name = bc[i].defaultName.value;
					string packageName = null;
					   
					if ( bc[i] is report )
					{
						if (((report)bc[i]).metadataModelPackage.value != null )
						{
							packageName = ((baseClass)((report)bc[i]).metadataModelPackage.value[0]).searchPath.value;
						}

					}
					else if (bc[i] is query )
					{
						if (((query)bc[i]).metadataModelPackage.value  != null )
						{
							packageName = ((baseClass)((query)bc[i]).metadataModelPackage.value[0]).searchPath.value;
						}
					}
					else if (bc[i] is analysis )
					{
						if (((analysis)bc[i]).metadataModelPackage.value != null )
						{
							packageName = ((baseClass)((analysis)bc[i]).metadataModelPackage.value[0]).searchPath.value;
						}
					}
					 
					if (packageName != null) 
					{
                        if (packageName.Equals(searchPackageName))
                        {
		
						Console.WriteLine (name);
						Console.WriteLine ("  Type:       " + bc[i].objectClass.value);
						Console.WriteLine ("  SearchPath: " + bc[i].searchPath.value);
					    }
                    }
                }
			}
			catch(Exception e)
			{
				Console.WriteLine (e.ToString());
			}
		}
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
			string  searchP = "/content//*";

			QueryContentStore qcs = new QueryContentStore();
			qcs.retrieveAllReports(searchP);
		}
	}
}
