/**
 * RepVersion.java
 *
 * Copyright � Cognos Incorporated. All Rights Reserved.
 * Cognos and the Cognos logo are trademarks of Cognos Incorporated.
 *
 * Description: (KB 1027119) - SDK: How to Retrieve all reports for a package 
 * 
 */

import com.cognos.developer.schemas.bibus._3.*;

public class QueryContentStore {

	
	// content manager service
	private ContentManagerService_ServiceLocator cmServiceLocator = null;
	private ContentManagerService_Port cmService = null;


	public static void main(String[] args) 
	{

		String endPointURL = "http://localhost:9300/p2pd/servlet/dispatch";      

		String searchPackageName = "/content/package[@name='GO Sales and Retailers']";
		QueryContentStore connect = new QueryContentStore();
	    connect.connectToReportServer(endPointURL);
	   
	   	  //Set the search path "searchP" to an existing report that has Burst Options set, 
          //has been bursted and the outputs were saved
		String searchP = "/content//*";
        try
	    {
	   	   //The user logged in should be a System Administrator 
           //in order to have access to all outputs
		   
		   connect.quickLogon("namespaceid", "username", "password");
		
		   SearchPathMultipleObject searchPobj = new SearchPathMultipleObject();
		
		   searchPobj.setValue(searchP);
		
           PropEnum props[] = {PropEnum.type,PropEnum.defaultName, PropEnum.searchPath, PropEnum.metadataModelPackage};
						

           BaseClass bc[] = connect.cmService.query(searchPobj,props, new Sort[]{}, new QueryOptions());

           System.out.println("Objects Referencing package: " + searchPackageName);
           
		   for (int i=0; i<bc.length ; i++)
		   { 
			  //Print the name just top confirm that it is not useful in this case 
              //and it is almost the same for each output
			   String name = bc[i].getDefaultName().getValue();
			   String packageName = null;
			   
			   if ( bc[i] instanceof Report ){
				   if (((Report)bc[i]).getMetadataModelPackage().getValue() != null ){
					   packageName = ((BaseClass)((Report)bc[i]).getMetadataModelPackage().getValue()[0]).getSearchPath().getValue();
				   }
				      
			   }
			   else if (bc[i] instanceof Query ){
				   if (((Query)bc[i]).getMetadataModelPackage().getValue() != null ){
					   packageName = ((BaseClass)((Query)bc[i]).getMetadataModelPackage().getValue()[0]).getSearchPath().getValue();
				   }
			   }

			   else if (bc[i] instanceof Analysis ){
				   if (((Analysis)bc[i]).getMetadataModelPackage().getValue() != null ){
					   packageName = ((BaseClass)((Analysis)bc[i]).getMetadataModelPackage().getValue()[0]).getSearchPath().getValue();
				   }
			   }
			   
			   if (packageName != null) {
				   if ( packageName.equals(searchPackageName) ){
			   
					   System.out.println(name);
					   System.out.println("  Type:       " + bc[i].getClass().getName());
					   System.out.println("  SearchPath: " + bc[i].getSearchPath().getValue());
				   }
			   }
		   
			 
			   
		  }
		
	   }
	   catch (Exception e)
	   {
	   		System.out.println(e);
	   		e.printStackTrace();
	   }
	}
	

	public String quickLogon(String namespace, String uid, String pwd) throws Exception
	{
		StringBuffer credentialXML = new StringBuffer();

		credentialXML.append("<credential>");
		credentialXML.append("<namespace>").append(namespace).append("</namespace>");
		credentialXML.append("<username>").append(uid).append("</username>");
		credentialXML.append("<password>").append(pwd).append("</password>");
		credentialXML.append("</credential>");

		String encodedCredentials = credentialXML.toString();

		cmService.logon(new XmlEncodedXML(encodedCredentials), new  SearchPathSingleObject[]{}/* this parameter does nothing, but is required */);

		return ("Logon successful as " + uid);
	}


	public void connectToReportServer (String sendPoint)
		{		
			// Default URL for CRN Content Manager

			try
			{

				java.net.URL endPoint = new java.net.URL(sendPoint);
			
 			
				//content manager service
			
				cmServiceLocator = new ContentManagerService_ServiceLocator();
				cmService = cmServiceLocator.getcontentManagerService(endPoint);

			
			}
			catch(Exception e)
			{
				System.out.println(e.getMessage());
			}
		}
}
