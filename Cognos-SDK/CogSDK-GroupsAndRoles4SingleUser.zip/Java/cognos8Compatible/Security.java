/**
 * Security.java
 *
 * Copyright � 2004 Cognos Incorporated. All Rights Reserved.
 * Cognos and the Cognos logo are trademarks of Cognos Incorporated.
 *
 * Description: (KB 1008113) - Cognos ReportNet SDK Java Sample to Extract All the Groups and Roles a User Belongs To
 *
*/
import com.cognos.developer.schemas.bibus._3.*;
import java.io.*;

public class Security {

	private CognosReportNetPortType oCrn = null;
	private CognosReportNetBindingStub stub = null;
	private BufferedWriter out = null;
	private String[] userMemberships = new String [30];
	private int userMembershipsLength = 0;
	private int sizeOfBuffer = 0;

	public void connectToReportServer (String endPoint) throws Exception
	{
		//Create a connection to the ReportNet service
		CognosReportNetServiceLocator service = new CognosReportNetServiceLocator();

		oCrn = stub = new CognosReportNetBindingStub(new java.net.URL(endPoint), service);
		stub.setTimeout(0);
	}

	public void logon(String namespace, String uid, String pwd) throws Exception
	{
		StringBuffer credentialXML = new StringBuffer();

		credentialXML.append("<credential>");
		credentialXML.append("<namespace>").append(namespace).append("</namespace>");
		credentialXML.append("<username>").append(uid).append("</username>");
		credentialXML.append("<password>").append(pwd).append("</password>");
		credentialXML.append("</credential>");

		String encodedCredentials = credentialXML.toString();

		oCrn.logon(encodedCredentials, new String[]{});

		System.out.println("Logon successful as " + uid);
	}
	
	public BaseClass[] getNamespaces() throws Exception
	{
		PropEnum[] props = new PropEnum[]{PropEnum.searchPath};
		
		BaseClass[] availableNamespaces = oCrn.query("/directory/namespace", props, new Sort[]{}, new QueryOptions());
		return availableNamespaces;
	}

	public String userMemberOfWhichNamespace(String userSearchPath, String namespaceID) throws Exception
	{
		PropEnum[] props = new PropEnum[]{PropEnum.searchPath};
		
		BaseClass[] availableNamespaces = getNamespaces();
		
		String namespace = "CAMID(\"" + namespaceID + "\")";
		String namespaceInfo = null;
		
		if(userSearchPath.compareToIgnoreCase("CAMID(\"::Anonymous\")") == 0)
		{
			if(sizeOfBuffer >= userMembershipsLength + 4)
			{
				userMemberships[userMembershipsLength++] = userSearchPath;
				userMemberships[userMembershipsLength++] = "CAMID(\"::All Authenticated Users\")";
				userMemberships[userMembershipsLength++] = "CAMID(\"::Everyone\")";
				userMemberships[userMembershipsLength++] = "CAMID(\":\")";
			}
			else
			{
				System.out.println("Please increase the amount of space allocated to the userMemberships buffer.  It is currently set to " + sizeOfBuffer + ".");
				System.exit(1);
			}
			
			return "CAMID(\":\")";
		}
		for (int i = 0; i < availableNamespaces.length; i++)
		{
			namespaceInfo = availableNamespaces[i].getSearchPath().getValue();
			
			if(namespaceInfo.compareToIgnoreCase(namespace) == 0)
			{
				BaseClass[] accountsInNamespace = oCrn.query(namespaceInfo + "//account",
															 props, new Sort[]{}, new QueryOptions());
				for(int j = 0; j < accountsInNamespace.length; j++)
				{
					if(userSearchPath.compareToIgnoreCase(accountsInNamespace[j].getSearchPath().getValue()) == 0)
					{
						if(sizeOfBuffer >= userMembershipsLength + 5)
						{
							userMemberships[userMembershipsLength++] = userSearchPath;
							userMemberships[userMembershipsLength++] = namespaceInfo;
							userMemberships[userMembershipsLength++] = "CAMID(\"::All Authenticated Users\")";
							userMemberships[userMembershipsLength++] = "CAMID(\"::Everyone\")";
							userMemberships[userMembershipsLength++] = "CAMID(\":\")";
						}
						else
						{
							System.out.println("Please increase the amount of space allocated to the userMemberships buffer.  It is currently set to " + sizeOfBuffer + ".");
							System.exit(1);
						}

						return namespaceInfo;
					}
				}
			}
		}
		out.write("\nAn error has occurred...");
		out.write("Please log into the same namespace the user you are querying belongs to...");
		out.write("and...");
		out.write("check the validity of the following user search path you provided:");
		out.write(userSearchPath);
		return null;
	}

	public void checkUserMembershipInGroups(String userSearchPath, String namespaceSearchPath) throws Exception
	{
		PropEnum[] namespaceProps = new PropEnum[]{PropEnum.searchPath};
		PropEnum[] groupProps = {PropEnum.searchPath, PropEnum.members};

		BaseClass[] groupsInNamespace = oCrn.query(namespaceSearchPath + "//group",
												   namespaceProps, new Sort[]{}, new QueryOptions());
		for(int i = 0; i < groupsInNamespace.length; i++)
		{
			Group group = (Group)oCrn.query(groupsInNamespace[i].getSearchPath().getValue(), groupProps, new Sort[]{}, new QueryOptions())[0];
			BaseClass obj = null;
			
			if(group.getMembers().getValue() != null)
			{
				for(int j = 0; j < group.getMembers().getValue().length; j++)
				{
					obj = group.getMembers().getValue()[j];
					
					if(obj.getSearchPath().getValue().compareToIgnoreCase(userSearchPath) == 0)
					{
						if(sizeOfBuffer >= userMembershipsLength + 1)
						{
							userMemberships[userMembershipsLength++] = group.getSearchPath().getValue();
						}
						else
						{
							System.out.println("Please increase the amount of space allocated to the userMemberships buffer.  It is currently set to " + sizeOfBuffer + ".");
							System.exit(1);
						}
					}
				}
			}
		}
	}

	public void checkUserMembershipInRoles(String userSearchPath, String namespaceSearchPath) throws Exception
	{
		PropEnum[] namespaceProps = new PropEnum[]{PropEnum.searchPath};
		PropEnum[] roleProps = {PropEnum.searchPath, PropEnum.members};

		BaseClass[] rolesInNamespace = oCrn.query(namespaceSearchPath + "//role",
												   namespaceProps, new Sort[]{}, new QueryOptions());
		for(int i = 0; i < rolesInNamespace.length; i++)
		{
			Role role = (Role)oCrn.query(rolesInNamespace[i].getSearchPath().getValue(), roleProps, new Sort[]{}, new QueryOptions())[0];
			
			if(role.getMembers().getValue() != null)
			{
				BaseClass obj = null;
				
				for(int j = 0; j < role.getMembers().getValue().length; j++)
				{
					obj = role.getMembers().getValue()[j];
					
					if(obj.getSearchPath().getValue().compareToIgnoreCase(userSearchPath) == 0)
					{
						if(sizeOfBuffer >= userMembershipsLength + 1)
						{
							userMemberships[userMembershipsLength++] = role.getSearchPath().getValue();
						}
						else
						{
							System.out.println("Please increase the amount of space allocated to the userMemberships buffer.  It is currently set to " + sizeOfBuffer + ".");
							System.exit(1);
						}
					}
				}
			}
		}
	}

	public void checkGroupMemberships(String namespaceSearchPath, boolean orderAscending) throws Exception
	{
		PropEnum[] namespaceProps = new PropEnum[]{PropEnum.searchPath};
		PropEnum[] groupProps = {PropEnum.searchPath, PropEnum.members};
		
		Sort[] sort = {new Sort()};
		
		if(orderAscending)
			sort[0].setOrder(OrderEnum.ascending);
		else
			sort[0].setOrder(OrderEnum.descending);
			
		sort[0].setPropName(PropEnum.defaultName);

		BaseClass[] groupsInNamespace = oCrn.query(namespaceSearchPath + "//group",
												   namespaceProps, sort, new QueryOptions());
		for(int i = 0; i < groupsInNamespace.length; i++)
		{
			Group group = (Group)oCrn.query(groupsInNamespace[i].getSearchPath().getValue(), groupProps, new Sort[]{}, new QueryOptions())[0];
			BaseClass obj = null;
			
			if(group.getMembers().getValue() != null)
			{
				for(int j = 0; j < group.getMembers().getValue().length; j++)
				{
					obj = group.getMembers().getValue()[j];
					
					for(int k = 0; k < userMembershipsLength; k++)
					{
						if(obj.getSearchPath().getValue().compareToIgnoreCase(userMemberships[k]) == 0)
						{
							boolean found = false;
							int m = 0;
							
							while(!found && m < userMembershipsLength)
							{
								if(userMemberships[m++].compareToIgnoreCase(group.getSearchPath().getValue()) == 0)
								{
									found = true;
								}
							}
							if(!found)
							{
								if(sizeOfBuffer >= userMembershipsLength + 1)
								{
									userMemberships[userMembershipsLength++] = group.getSearchPath().getValue();
								}
								else
								{
									System.out.println("Please increase the amount of space allocated to the userMemberships buffer.  It is currently set to " + sizeOfBuffer + ".");
									System.exit(1);
								}
							}
						}
					}
				}
			}
		}
	}

	public void checkRoleMemberships(String namespaceSearchPath, boolean orderAscending) throws Exception
	{
		PropEnum[] namespaceProps = new PropEnum[]{PropEnum.searchPath};
		PropEnum[] roleProps = {PropEnum.searchPath, PropEnum.members};
		
		Sort[] sort = {new Sort()};
		
		if(orderAscending)
			sort[0].setOrder(OrderEnum.ascending);
		else
			sort[0].setOrder(OrderEnum.descending);
			
		sort[0].setPropName(PropEnum.defaultName);

		BaseClass[] rolesInNamespace = oCrn.query(namespaceSearchPath + "//role",
												   namespaceProps, sort, new QueryOptions());
		for(int i = 0; i < rolesInNamespace.length; i++)
		{
			Role role = (Role)oCrn.query(rolesInNamespace[i].getSearchPath().getValue(), roleProps, new Sort[]{}, new QueryOptions())[0];
			BaseClass obj = null;
			
			if(role.getMembers().getValue() != null)
			{
				for(int j = 0; j < role.getMembers().getValue().length; j++)
				{
					obj = role.getMembers().getValue()[j];
					
					for(int k = 0; k < userMembershipsLength; k++)
					{
						if(obj.getSearchPath().getValue().compareToIgnoreCase(userMemberships[k]) == 0)
						{
							boolean found = false;
							int m = 0;
							
							while(!found && m < userMembershipsLength)
							{
								if(userMemberships[m++].compareToIgnoreCase(role.getSearchPath().getValue()) == 0)
								{
									found = true;
								}
							}
							if(!found)
							{
								if(sizeOfBuffer >= userMembershipsLength + 1)
								{
									userMemberships[userMembershipsLength++] = role.getSearchPath().getValue();
								}
								else
								{
									System.out.println("Please increase the amount of space allocated to the userMemberships buffer.  It is currently set to " + sizeOfBuffer + ".");
									System.exit(1);
								}
							}
						}
					}
				}
			}
		}
	}

	public static void main(String args[])
	{
		// connection to the ReportNet service
		String endPoint = "http://localhost:9300/p2pd/servlet/dispatch";
		// you must log in as a System Administrator who belongs to the same namespace as the user being queried
		String namespaceID = "namespaceID";
		String userID = "userID";
		String password = "password";
		
				
		// search path of the user for which you want to list the groups and roles he belongs to
		String userSearchPath = "CAMID(\"Sun One LDAP:u:uid=ftemp,ou=people\")";
		
		// no need to edit this value
		String cognosNamespaceSearchPath = "CAMID(\":\")";
		final boolean orderAscending = true;
		final boolean orderDescending = false;
		boolean userAnonymous = false;
		Security test = new Security();

		try
		{
			test.connectToReportServer(endPoint);
			//log in as an administrator to be able to have access to the security settings  
			test.logon(namespaceID, userID, password);
		
			test.sizeOfBuffer = test.userMemberships.length;
			String namespaceSearchPath = test.userMemberOfWhichNamespace(userSearchPath, namespaceID);
			if(namespaceSearchPath.compareToIgnoreCase(cognosNamespaceSearchPath) == 0)
				userAnonymous = true;
			
			if(namespaceSearchPath != null)
			{
				if(!userAnonymous)
					test.checkUserMembershipInGroups(userSearchPath, namespaceSearchPath);
				test.checkUserMembershipInGroups(userSearchPath, cognosNamespaceSearchPath);

				if(!userAnonymous)
					test.checkGroupMemberships(namespaceSearchPath, orderAscending);
				test.checkGroupMemberships(cognosNamespaceSearchPath, orderAscending);

				test.checkGroupMemberships(cognosNamespaceSearchPath, orderDescending);
				if(!userAnonymous)
					test.checkGroupMemberships(namespaceSearchPath, orderDescending);

				test.checkUserMembershipInRoles(userSearchPath, cognosNamespaceSearchPath);
				test.checkRoleMemberships(cognosNamespaceSearchPath, orderAscending);
				test.checkRoleMemberships(cognosNamespaceSearchPath, orderDescending);
				
				System.out.println("\nUser " + userSearchPath + ":");
				
				for(int i = 0; i < test.userMembershipsLength; i++)
				{
					System.out.println("Member of " + test.userMemberships[i]);
				}
			}
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
		}
		System.out.println("\nDone.");
	}
}